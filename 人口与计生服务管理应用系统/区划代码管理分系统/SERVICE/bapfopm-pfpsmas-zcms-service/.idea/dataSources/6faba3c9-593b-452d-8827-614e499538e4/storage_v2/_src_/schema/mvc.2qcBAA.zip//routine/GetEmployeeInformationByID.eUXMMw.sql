CREATE FUNCTION GetEmployeeInformationByID(id INT)
  RETURNS VARCHAR(300)
  BEGIN  
    RETURN(SELECT CONCAT('employee name:',employee_name,'---','salary: ',employee_salary) FROM employees WHERE employee_id=id);  
END;

